#version 120
//
// background.frag
//
uniform sampler2D image;
varying vec2 texcoord;

void main(void)
{
  gl_FragColor = texture2D(image, texcoord);
}
