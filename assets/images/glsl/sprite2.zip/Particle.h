#ifndef PARTICLE_H
#define PARTICLE_H

class Particle {
  float p[3];     // �ʒu
  float v[3];     // ���x
  static float g; // �d�͉����x
  static float h; // ���˓_�̍���
  static float l; // �����ʂ̍���
  static float a; // ������
  static float s; // �����x
 public:
  Particle();
  Particle(const float p[3], const float v[3]);
  ~Particle() {};
  static void gravity(float g) { Particle::g = g; }
  static void speed(float s) { Particle::s = s; }
  static void height(float h) { Particle::h = h; }
  static void level(float l) { Particle::l = l; }
  static void attenuation(float a) { Particle::a = a; }
  const float *get() const { return p; }
  void get(float p[3]) const { p[0] = this->p[0]; p[1] = this->p[1]; p[2] = this->p[2]; }
  void update(float t);
};

#endif
