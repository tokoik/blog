#include <cstdlib>

#include "Particle.h"

float Particle::g = -0.001f;
float Particle::s = 0.02f;
float Particle::h = 1.0f;
float Particle::l = -1.0f;
float Particle::a = 0.6f;

Particle::Particle()
{
  p[0] = 0.0;
  p[1] = h;
  p[2] = 0.0;
  v[0] = ((float)rand() / (float)RAND_MAX - 0.5f) * s;
  v[1] = ((float)rand() / (float)RAND_MAX * 0.5f) * s;
  v[2] = ((float)rand() / (float)RAND_MAX - 0.5f) * s;
}

Particle::Particle(const float p[3], const float v[3])
{
  this->p[0] = p[0];
  this->p[1] = p[1];
  this->p[2] = p[2];
  this->v[0] = v[0];
  this->v[1] = v[1];
  this->v[2] = v[2];
};

void Particle::update(float t)
{
  p[0] += v[0] * t;
  v[1] += g * t;
  p[1] += v[1] * t;
  if (p[1] < l) {
    p[1] = l;
    v[1] = -a * v[1];
  }
  p[2] += v[2] * t;
}
