﻿//
// 折れ線を描く
//
//     n: 結び目の数 (線分の数 + 1)
//     p: 結び目の位置 (二次元)
//
extern void polyline(int n, double (*p)[2]);

// 時間間隔
static const double dt = (1.0 / 60.0);

// 結び目の初期位置
static double position[][2] =
{
  { 0.0, 0.0 },
  { 0.0, 50.0 }
};

// 結び目の数
static const int points = sizeof position / sizeof position[0];

// 描画
void draw(void)
{
  // 折れ線
  polyline(points, position);
}
