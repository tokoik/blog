﻿#include <cmath>
#include <cstdlib>
#include "gg.h"

static int num = 0;                       // 与えられた結び目の数
static double (*src)[2];                  // 与えられた結び目の位置の元データ
static GLdouble (*dst)[2] = 0;            // 与えられた結び目の位置のコピー
static bool *fix = 0;                     // 結び目が固定されていることを示すマーク
static GLfloat (*col)[3] = 0;             // 結び目の色
static double tstep;                      // 経過時間 (秒)

static const GLfloat cfix[] = { 0.0f, 0.0f, 1.0f };   // 固定点の色
static const GLfloat cmov[] = { 1.0f, 0.0f, 0.0f };   // 移動点の色

//
// 折れ線を描く
//
//     n: 結び目の数 (線分の数 + 1)
//     p: 結び目の位置 (二次元)
//
void polyline(int n, double (*p)[2])
{
  // 結び目の数が以前と違ったらメモリを確保し直す
  if (n != num)
  {
    // 結び目の数を保存しておく
    num = n;

    // メモリを確保する
    delete[] fix;
    fix = new bool[n];
    delete[] dst;
    dst = new GLdouble[n][2];
    delete[] col;
    col = new GLfloat[n][3];

    // データを初期化する
    fix[0] = true;
    dst[0][0] = p[0][0];
    dst[0][1] = p[0][1];
    col[0][0] = cfix[0];
    col[0][1] = cfix[1];
    col[0][2] = cfix[2];
    for (int i = 1; i < n; ++i)
    {
      fix[i] = false;
      dst[i][0] = p[i][0];
      dst[i][1] = p[i][1];
      col[i][0] = cmov[0];
      col[i][1] = cmov[1];
      col[i][2] = cmov[2];
    }
  }
  else
  {
    for (int i = 0; i < n; ++i)
    {
      if (!fix[i])
      {
        // 固定されていない結び目の位置を更新する
        dst[i][0] = p[i][0];
        dst[i][1] = p[i][1];
      }
      else
      {
        // 固定された結び目の位置を固定位置に戻す
        p[i][0] = dst[i][0];
        p[i][1] = dst[i][1];
      }
    }
  }

  // 元データのポインタを覚えておく
  src = p;

  // 折れ線の描画
  glVertexPointer(2, GL_DOUBLE, 0, dst);
  glDisableClientState(GL_COLOR_ARRAY);
  glColor3d(0.0, 0.0, 0.0);
  glDrawArrays(GL_LINE_STRIP, 0, n);
  glEnableClientState(GL_COLOR_ARRAY);
  glColorPointer(3, GL_FLOAT, 0, col);
  glDrawArrays(GL_POINTS, 0, n);
}

//
// 経過時間を得る (秒)
//
double elapsed(void)
{
  return tstep;
}

////////////////////////////////////////////////////////////////////////

#define KNOTSIZE  7.0                     // 結び目の大きさ
#define AREASIZE  200.0                   // スクリーンの高さ

////////////////////////////////////////////////////////////////////////

static double scale[2];                   // 表示領域→スクリーンの拡大率
static double offset[2];                  // 表示領域→スクリーンの変位
static double psize[2];                   // スクリーン上の点の大きさ
static int hit = -1;                      // ドラッグ中の結び目の番号

//
// polyline() を使って図形を描く手続き
//
extern void draw(void);

//
// 実際の描画
//
static void display(void)
{
  // 経過時間を求める
  static int last = 0;
  int now = glutGet(GLUT_ELAPSED_TIME);
  tstep = (last == 0) ? 0.0 : (double)(now - last) * 0.001;
  last = now;

  // 図形を表示する
  glClear(GL_COLOR_BUFFER_BIT);
  draw();
  glutSwapBuffers();
}

//
// ウィンドウのリサイズ
//
static void resize(int w, int h)
{
  // アスペクト比
  double aspect = (double)w / (double)h;

  // マウスの位置からスクリーン上の位置を求める
  offset[0] = AREASIZE * aspect * 0.5;
  offset[1] = AREASIZE * 0.5;
  scale[0] = AREASIZE * aspect / (double)w;
  scale[1] = AREASIZE / (double)h;
  psize[0] = fabs(KNOTSIZE * scale[0]);
  psize[1] = fabs(KNOTSIZE * scale[1]);

  // ウィンドウ全体をビューポートにする
  glViewport(0, 0, w, h);

  // 変換行列の初期化
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glOrtho(-offset[0], offset[0], -offset[1], offset[1], -1.0, 1.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
}

//
// 結び目の選択
//
void mouse(int button, int state, int x, int y)
{
  // スクリーン上のマウス位置
  double sx = ((double)x + 0.5) * scale[0] - offset[0];
  double sy = offset[1] - ((double)y + 0.5) * scale[1];
  static bool fstatus = false;

  switch (button)
  {
  case GLUT_LEFT_BUTTON:
    if (state == GLUT_DOWN)
    {
      for (int i = 0; i < num; ++i)
      {
        // スクリーン上のマウスの位置と結び目の位置の差
        double dx = sx - dst[i][0];
        double dy = sy - dst[i][1];

        // マウスと結び目が点の大きさよりも近ければ
        if (fabs(dx) <= psize[0] && fabs(dy) <= psize[1])
        {
          // その結び目を記憶する
          hit = i;

          // その結び目が固定されているかどうかを記憶する
          fstatus = fix[i];

          // その結び目を固定する
          fix[i] = true;

          return;
        }
      }
    }
    else
    {
      // ドラッグしていた結び目の固定状態を戻す
      if (hit >= 0) fix[hit] = fstatus;
    }

    // どの結び目も選べなかった
    hit = -1;
    break;
  case GLUT_MIDDLE_BUTTON:
    break;
  case GLUT_RIGHT_BUTTON:
    if (state == GLUT_DOWN)
    {
      for (int i = 0; i < num; ++i)
      {
        // スクリーン上のマウスの位置と結び目の位置の差
        double dx = sx - dst[i][0];
        double dy = sy - dst[i][1];

        // マウスと結び目が点の大きさよりも近ければ
        if (fabs(dx) <= psize[0] && fabs(dy) <= psize[1])
        {
          // その結び目の移動点／固定点を反転する
          fix[i] = !fix[i];
          if (fix[i])
          {
            // 固定点の色
            col[i][0] = cfix[0];
            col[i][1] = cfix[1];
            col[i][2] = cfix[2];
          }
          else
          {
            // 移動点の色
            col[i][0] = cmov[0];
            col[i][1] = cmov[1];
            col[i][2] = cmov[2];

            // 移動点の位置
            src[i][0] = dst[i][0];
            src[i][1] = dst[i][1];
          }
          return;
        }
      }
    }
    break;
  default:
    break;
  }
}

//
// 結び目のドラッグ
//
void motion(int x, int y)
{
  if (hit >= 0)
  {
    dst[hit][0] = src[hit][0] = ((double)x + 0.5) * scale[0] - offset[0];
    dst[hit][1] = src[hit][1] = offset[1] - ((double)y + 0.5) * scale[1];
  }
}

//
// キーボードの操作
//
void keyboard(unsigned char key, int x, int y)
{
  switch (key)
  {
  case '\033':
  case 'q':
  case 'Q':
    exit(0);
  default:
    break;
  }
}

//
// 画面の最描画
//
void idle(void)
{
  glutPostRedisplay();
}

//
// 初期設定
//
static void init(void)
{
  gg::ggInit();
  glClearColor(1.0, 1.0, 1.0, 0.0);
  glPointSize(KNOTSIZE);
  glEnableClientState(GL_VERTEX_ARRAY);
}

int main(int argc, char *argv[])
{
  glutInitWindowSize(800, 600);
  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
  glutCreateWindow("Biyooooooooon!");
  glutDisplayFunc(display);
  glutReshapeFunc(resize);
  glutMouseFunc(mouse);
  glutMotionFunc(motion);
  glutKeyboardFunc(keyboard);
  glutIdleFunc(idle);
  init();
  glutMainLoop();

  return EXIT_SUCCESS;
}
