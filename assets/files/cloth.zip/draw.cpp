﻿//
// 網を描く
//
//     m: 横方向の結び目の数 (線分の数 + 1)
//     n: 縦方向の結び目の数 (線分の数 + 1)
//     p: 結び目の位置 (三次元)
//
extern void net(int m, int n, void *p);

// 時間間隔
static const double dt = (1.0 / 60.0);

// 結び目の数
static const int pointsi = 10;
static const int pointsj = 10;

// 結び目の位置
static double position[pointsi][pointsj][3];

// 描画
void draw(void)
{
  // 網
  net(pointsi, pointsj, position);

  //
  // position の更新は net() の実行後に行う
  //
}
