/*
 *  main.c
 *  �PROJECTNAME�
 *
 *  Created by �FULLUSERNAME� on �DATE�.
 *  Copyright �ORGANIZATIONNAME� �YEAR�. All rights reserved.
 */

#include <GLUT/glut.h>

static void display(void)
{
  glClear(GL_COLOR_BUFFER_BIT);
  glFlush();
}

static void init(void)
{
  glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
}

int main(int argc, char *argv[])
{
  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_RGB);
  glutCreateWindow("�PROJECTNAME�");
  glutDisplayFunc(display);
  init();
  glutMainLoop();

  return 0;
}
